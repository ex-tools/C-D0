// Cloudflare Worker License Server
const LICENSE_SERVER_URL = "https://extension-tools.div2.workers.dev";
